﻿// Mai Thị Thảo Chi_2110A03_W710TH2022.008

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace bai_11
{
    public class nhanvien
    {
        string hoten;
        string namsinh;

        public string Hoten
        {
            get { return hoten; }
            set { hoten = value; }
        }

        public string Namsinh
        {
            get { return namsinh; }
            set { namsinh = value;}
        }
    }
}